from gps import *
import time
import RPi.GPIO as GPIO
import cv2
import numpy as np
from i2clibraries import i2c_hmc5883l
from math import atan2, pi
from geopy.distance import geodesic
import cv2
import numpy as np


gpsd = gps(mode=WATCH_ENABLE)

def iniciaMotor():

    global escEsq
    global escDir

    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(29, GPIO.OUT)
    GPIO.setup(33, GPIO.OUT)

    escEsq = GPIO.PWM(29, 50)
    escDir = GPIO.PWM(33, 50)
    escEsq.start(0)
    escDir.start(0)

    time.sleep(2)

    escEsq.ChangeDutyCycle(3)
    escDir.ChangeDutyCycle(3)

    time.sleep(1)

def getPosicao(gps):

    global latAtual
    global lonAtual

    px = gpsd.next()

    if px['class'] == 'TPV':
        latAtual = getattr(px, 'lat', "unknown")
        lonAtual = getattr(px, 'lon', "unknown")
        print("latitude: " + str(latAtual) + "longitude: " + str(lonAtual))


def getWaypoints():

    global latDestino
    global lonDestino
    global i

    latDestino = [1,2,3]
    lonDestino = [1,2,3]

    for i in range(3):
        latDestino[i] = float(input("latitude: "))
        lonDestino[i] = float(input("longitude: "))

    i = 0

def chamaBussola():

    global bussola
    
    bussola = i2c_hmc5883l.i2c_hmc5883l(1)
    bussola.setContinuousMode()
    bussola.setDeclination(-20, 10)

def calculaAngulo():

    global direcaoGraus

    deltaLat = latDestino[i] - latAtual
    deltaLon = lonDestino[i] - lonAtual
   
    direcaoGraus = atan2(deltaLon, deltaLat)/pi*180
    
    if direcaoGraus < 0:
        direcaoGraus = 360 + direcaoGraus

def segueCone(capture):
    
    global mask
    global width
    global height
    global centerImageX
    global centerImageY
    global minimum_area
    global maximum_area

    cap = cv2.VideoCapture(0)
    ret, capture = cap.read()

    width = int(cap.get(3))
    height =(cap.get(4))

    minimum_area = 250
    maximum_area = 100000

    lowerOrangeLA = np.array([0, 68, 255])
    upperOrangeLA = np.array([180, 255, 255])

    lowerLaranjaLD = np.array([0, 109, 36])
    upperLaranjaLD = np.array([180, 255, 255])

    centerImageX = width / 2
    centerImageY = height / 2

    hsv = cv2.cvtColor(capture, cv2.COLORBGR2HSV)
    laranja = cv2.inRange(hsv, lowerLaranjaLA, upperLaranjaLA)
    blur = cv2.GaussianBlur(laranja, (7,7), 0)
    mask = cv2.Canny(blur, 50, 150)


x = 0

while(x != 20):
    getPosicao(gps)
    x += 1
    print("ta indo")


coneLonge = True
procurandoAngulo = True
achouAngulo = False

iniciaMotor()
getWaypoints()
chamaBussola()
calculaAngulo()

minAngle = direcaoGraus - 3
maxAngle = direcaoGraus + 3


while i != 3:

    ret, capture = cap.read()
    areaObject = 0
    objectX = 0
    objectY = 0

    segueCone(capture)

    for contours in contorno:
        
        areaContorno = cv2.contourArea(contours)

        if areaContorno > 1200:
            x, y, width, height = cv2.boundingRect(contours)
            cv2.rectangle(capture, (x,y), (x + width, y + heigh), (0, 0, 255), 3)

            coneLonge = False

            areaFound = width * height
            centerX = x + (width / 2)
            centerY = y + (height / 2)
            
            if areaObject < areaFound:
                areaObject = areaFound
                objectX = centerX
                objectY = centerY

            if areaObject > 0:
                coneLocation = [areaObject, objectX, objectY]

            else: 

                coneLocation = None

            if coneLocation:

                if coneLocation[0] > minimum_area and coneLocation[0] < maximum_area:
                    if coneLocation[1] > (centerImageX + (width / 3)):
                        escDir.ChangeDutyCycle(6.6)
                        escEsq.ChangeDutyCycle(6.2)
                        print("Indo para a direita")

                    elif coneLocation[1] < (centerImageX + (width / 3)):
                        escDir.ChangeDutyCycle(6.4)
                        escEsq.ChangeDutyCycle(7.4)
                        print("Indo para a esquerda")
                    
                    else: 
                        escDir.ChangeDutyCycle(6.4)
                        escEsq.ChangeDutyCycle(7)
                        print("Seguindo em frente")

            if areaContorno > 3000:
                coneLonge = True
                print("Cone muito perto")
                    
    while coneLonge:
        while procurandoAngulo:
            direcao = bussola.getHeading()
            anguloAtual = direcao[0]
    
            if anguloAtual > direcaoGraus:
                print("virando para a direita")
                escEsq.ChangeDutyCycle(6.4)
                escDir.ChangeDutyCycle(0)
                if (minAngle <= anguloAtual <= maxAngle):
                    procurandoAngulo = False
                    achouAngulo = True
                    escEsq.ChangeDutyCycle(0)
                    escDir.ChangeDutyCycle(0)
    
            if anguloAtual < direcaoGraus:
                print("virando para esquerda")
                escEsq.ChangeDutyCycle(0)
                escDir.ChangeDutyCycle(6.6)
                if (minAngle <= anguloAtual <= maxAngle):
                    procurandoAngulo = False
                    achouAngulo = True
                    escEsq.ChangeDutyCycle(0)
                    escDir.ChangeDutyCycle(0)
    
        while achouAngulo:
            print("indo em direção ao angulo")
            escEsq.ChangeDutyCycle(6.4)
            escDir.ChangeDutyCycle(7)
        
i+= 1

if (i == 3):
    print("trajeto concluído")
    
else:
    procurandoAngulo = True
    achouAngulo = False
    
